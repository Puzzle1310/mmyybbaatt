package com._02_seung.section01;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


import static com._02_seung.common.JDBCTemplate.getConnection;
import static com._02_seung.common.JDBCTemplate.close;

public class Application02 {

    public static void main(String[] args) {

        Connection con = getConnection();


        Statement stmt = null;


        ResultSet rset = null;

        try {

            stmt = con.createStatement();

            int menuCode = 10;
            String query = "SELECT menu_name, menu_price FROM tbl_menu WHERE menu_code = " + menuCode;
            rset = stmt.executeQuery(query);
            if(rset.next()) {
                System.out.println(rset.getString("menu_name") + "은(는) "
                        + rset.getString("menu_price") + "원");
            }

        } catch (SQLException e) {
            e.printStackTrace();

        } finally {
            close(rset);
            close(stmt);
            close(con);
        }

    }

}

