package com._02_seung.section01;

import com._02_seung.dto.EmployeeDTO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import static com._02_seung.common.JDBCTemplate.close;
import static com._02_seung.common.JDBCTemplate.getConnection;

public class Application05 {

    public static void main(String[] args) {
        /* [ 모든 직원의 정보를 DTO 객체에 담고, 이를 ArrayList에 담아 출력하기 ] */

        /* 1. Connection 생성 */
        Connection con = getConnection();

        /* 2. Statement 선언 */
        Statement stmt = null;

        /* 3. ResultSet 선언 */
        ResultSet rset = null;

        /* 4. 한 행(row)의 정보를 담을 DTO 객체와 여러 DTO를 하나의 인스턴스로 묶기 위한 List 선언 */
        EmployeeDTO row = null;
        List<EmployeeDTO> empList = null;

        /* 5. 쿼리문 작성 */
        String query = "SELECT * FROM EMPLOYEE";

        try {

            /* 6. Statement 인스턴스 생성 */
            stmt = con.createStatement();

            /* 7. ResultSet으로 결과를 반환 받음 */
            rset = stmt.executeQuery(query);

            empList = new ArrayList<>();

            while(rset.next()) {

                /* 8-1. DTO 객체를 생성하고, ResultSet에 담긴 결과물을 컬럼명을 이용해 꺼내어 DTO 객체에 set */
                row = new EmployeeDTO();

                row.setEmpId(rset.getString("EMP_ID"));
                row.setEmpName(rset.getString("EMP_NAME"));
                row.setEmpNo(rset.getString("EMP_NO"));
                row.setEmail(rset.getString("EMAIL"));
                row.setPhone(rset.getString("PHONE"));
                row.setDeptCode(rset.getString("DEPT_CODE"));
                row.setJobCode(rset.getString("JOB_CODE"));
                row.setSalLevel(rset.getString("SAL_LEVEL"));
                row.setSalary(rset.getInt("SALARY"));
                row.setBonus(rset.getDouble("BONUS"));
                row.setManagerId(rset.getString("MANAGER_ID"));
                row.setHireDate(rset.getDate("HIRE_DATE"));
                row.setEntDate(rset.getDate("ENT_DATE"));
                row.setEntYn(rset.getString("ENT_YN"));

                /* 8-2. 8-1에서 set한 객체를 List에 추가  */
                empList.add(row);
            }

        } catch (SQLException e) {
            e.printStackTrace();

        } finally {
            /* 9. 자원 반납 */
            close(rset);
            close(stmt);
            close(con);
        }

        /* 10. for문을 활용해 리스트의 내용 출력 */
        for(EmployeeDTO emp : empList) {
            System.out.println(emp);
        }

    }

}
