package com._01_seunghyeon.section02.template;

import java.sql.Connection;

import static com._01_seunghyeon.section02.template.jdbcTemplate.close;
import static com._01_seunghyeon.section02.template.jdbcTemplate.getConnection;

public class Application {

    public static void main(String[] args) {


        Connection con = getConnection();
        System.out.println(con);

       close(con);

    }


    }



