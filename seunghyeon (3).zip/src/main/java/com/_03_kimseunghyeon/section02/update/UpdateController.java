package com._03_kimseunghyeon.section02.update;

import com._03_kimseunghyeon.model.dto.MenuDTO;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;

import static com._03_kimseunghyeon.common.JDBCTemplate.close;
import static com._03_kimseunghyeon.common.JDBCTemplate.getConnection;

public class UpdateController {

    public int updateMenu(MenuDTO changedMenu) {

        Connection con = getConnection();

        PreparedStatement pstmt = null;
        int result = 0;

        Properties prop = new Properties();

        try {
            prop.loadFromXML(new FileInputStream("src/main/java/com/_03_kimseunghyeon/section03/mapper/menu-query.xml"));
            String query = prop.getProperty("updateMenu");

            pstmt = con.prepareStatement(query);
            pstmt.setString(1, changedMenu.getName());
            pstmt.setInt(2, changedMenu.getPrice());
            pstmt.setInt(3, changedMenu.getCode());

            result = pstmt.executeUpdate();

        } catch (IOException | SQLException e) {
            e.printStackTrace();

        } finally {
            close(pstmt);
            close(con);
        }

        return result;
    }

}
