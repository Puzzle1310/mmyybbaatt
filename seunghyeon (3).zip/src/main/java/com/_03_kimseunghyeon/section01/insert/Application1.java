package com._03_kimseunghyeon.section01.insert;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;

import static com._03_kimseunghyeon.common.JDBCTemplate.close;
import static com._03_kimseunghyeon.common.JDBCTemplate.getConnection;

public class Application1 {

    public static void main(String[] args) {

        Connection con = getConnection();

        PreparedStatement pstmt = null;
        int result = 0;

        Properties prop = new Properties();

        try {
            prop.loadFromXML(
                    new FileInputStream("src/main/java/com/_03_kimseunghyeon/section01/insert/mapper/menu-query.xml")
            );

            String query = prop.getProperty("insertMenu");

            System.out.println(query);

            pstmt = con.prepareStatement(query);
            pstmt.setString(1, "스파이시 쉬림프");
            pstmt.setInt(2, 11000);
            pstmt.setInt(3, 4);
            pstmt.setString(4, "Y");

            result = pstmt.executeUpdate();

        } catch (IOException | SQLException e) {
            e.printStackTrace();

        } finally {
            close(pstmt);
            close(con);
        }

        if(result > 0) {
            System.out.println("메뉴 등록 성공");

        } else {
            System.out.println("메뉴 등록 실패");
        }

    }

}
