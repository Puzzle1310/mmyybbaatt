package com.mybatis01.section01.javaconfig;

import org.apache.ibatis.datasource.pooled.PooledDataSource;
import org.apache.ibatis.mapping.Environment;
import org.apache.ibatis.session.Configuration;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.apache.ibatis.transaction.jdbc.JdbcTransactionFactory;

import java.util.Date;

public interface Mapper {

    class Application {

        private static String driver = "com.mysql.cj.jdbc.Driver";
        private static String url = "jdbc:mysql://localhost/bookdto";
        private static String user = "seunghyeon";
        private  static  String password = "seunghyeon";

        public static void main(String[]args){
           /* Environment environment = new Environment(
                    "dev"                                                   //환경 정보 이름
                    , new JdbcTransactionFactory()                      //트랜잭션 매니저 종류 결정 (JDBC or MANAGED)
                    , new PooledDataSource(driver, url, user, password) //ConnectionPool 사용 유무 (Pooled or UnPooled)
            );

            Configuration configuration = new configuration(environment);

            configuration.addMapper(Mapper.class);

            SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(configuration); {
            }
            Mapper mapper = sqlSession.getMapper(Mapper.class);

            java.util.Date date = mapper.selectSysdate();
            System.out.println(date);

            sqlSession.close(); */
            Environment environment = new Environment(
                    "dev"                                                   //환경 정보 이름
                    , new JdbcTransactionFactory()                      //트랜잭션 매니저 종류 결정 (JDBC or MANAGED)
                    , new PooledDataSource(driver, url, user, password) //ConnectionPool 사용 유무 (Pooled or UnPooled)
            );

            /* 생성한 환경 설정 정보로 MyBatis 설정 객체 생성*/
            Configuration configuration = new Configuration(environment);

            /* 설정 객체에 mapper 등록 */
            configuration.addMapper(Mapper.class);

            /*
             * SqlSessionFactory : SqlSession 객체를 생성하기 위한 팩토리 역할의 인터페이스
             * SqlSessionFactoryBuilder : SqlSessionFactory 인터페이스 타입의 하위 구현 객체를 생성하기 위한 빌더 역할
             * build() : 설정에 대한 정보를 담은 Configuration 타입의 객체 혹은 외부 설정 파일과 연결된 Stream을 인자로 전달하면
             *           SqlSessionFactory 인터페이스 타입의 객체를 반환하는 메소드
             * */
            SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(configuration);

            /*
             * openSession() : SqlSession 인터페이스 타입의 객체를 반환하는 메소드 (boolean 타입의 인자 전달 가능)
             * - false : Connection 인터페이스 타입 객체로 DML 수행 후 auto commit에 대한 옵션을 false로 지정 (권장)
             * - true : Connection 인터페이스 타입 객체로 DML 수행 후 auto commit에 대한 옵션을 true로 지정
             * */
            SqlSession sqlSession = sqlSessionFactory.openSession(false);

            /* getMapper() : Configuration에 등록된 매퍼를 동일 타입에 대해 반환하는 메소드 */
            Mapper mapper = sqlSession.getMapper(Mapper.class);

            java.util.Date date = mapper.selectSysdate();
            System.out.println(date);

            /* close() : SqlSession 객체를 반납하는 메소드 */
            sqlSession.close();








        }
    }

    Date selectSysdate();
}
