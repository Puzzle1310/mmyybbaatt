package com.mybatis01.section01.javaconfig;

public class Application {

}