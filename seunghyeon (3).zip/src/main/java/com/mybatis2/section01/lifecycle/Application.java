package com.mybatis2.section01.lifecycle;

import static com.mybatis2.section01.lifecycle.Template.getSqlSession;

public class Application {

    public static void main(String[] args) {
        getSqlSession();
        getSqlSession();
        getSqlSession();
        getSqlSession();
        getSqlSession();
    }

}
