package com.mybatis5.section01.xmlmapper;

import com.mybatis5.common.CategoryDTO;
import com.mybatis5.common.MenuAndCategoryDTO;
import com.mybatis5.common.MenuDTO;

import java.util.Scanner;

public class Application {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ElementTestService elementTestService = new ElementTestService();

        do {
            System.out.println("========== Mapper Elements test ==========");
            System.out.println("1. <cache>");
            System.out.println("2. <resultMap> Sub Menu");
            System.out.println("3. <sql>");
            System.out.println("4. <insert> Sub Menu");
            System.out.println("9. 프로그램 종료");
            System.out.print("실행할 메뉴 번호를 입력하세요 : ");
            int no = sc.nextInt();

            switch (no) {
                case 1: elementTestService.selectCacheTest(); break;
                case 2: resultMapSubMenu(); break;
                case 3: elementTestService.selectSqlTest(); break;
                case 4: insertSubMenu(); break;
                case 9: System.out.println("프로그램을 종료합니다."); return;
            }
        } while (true);
    }

    private static void resultMapSubMenu() {
        Scanner sc = new Scanner(System.in);
        ElementTestService elementTestService = new ElementTestService();

        do {
            System.out.println("========== <resultMap> Sub Menu ==========");
            System.out.println("1. <resultMap>");
            System.out.println("2. <constructor>");
            System.out.println("3. <association>");
            System.out.println("4. <collection>");
            System.out.println("9. 이전 메뉴로 이동");
            System.out.print("실행할 메뉴 번호를 입력하세요 : ");
            int no = sc.nextInt();

            switch (no) {
                case 1: elementTestService.selectResultMapTest(); break;
                case 2: elementTestService.selectResultMapConstructorTest(); break;
                case 3: elementTestService.selectResultMapAssociationTest(); break;
                case 4: elementTestService.selectResultMapCollectionTest(); break;
                case 9: return;
            }
        } while (true);
    }

    private static void insertSubMenu() {
        Scanner sc = new Scanner(System.in);
        ElementTestService elementTestService = new ElementTestService();

        do {
            System.out.println("========== <insert> Sub Menu ==========");
            System.out.println("1. 신메뉴 등록");
            System.out.println("2. 신규 카테고리 등록 후, 해당 신메뉴 등록");
            System.out.println("9. 이전 메뉴로 이동");
            System.out.print("실행할 메뉴의 번호를 입력하세요 : ");
            int no = sc.nextInt();

            switch (no) {
                case 1: elementTestService.insertMenu(inputNewMenu()); break;
                case 2: elementTestService.insertCategoryAndMenu(inputNewCategoryAndMenu()); break;
                case 9: return;
            }
        } while (true);
    }

    private static MenuDTO inputNewMenu() {
        Scanner sc = new Scanner(System.in);

        System.out.print("신메뉴의 이름을 입력하세요 : ");
        String name = sc.nextLine();
        System.out.print("신메뉴의 가격을 입력하세요 : ");
        int price = sc.nextInt();
        System.out.print("신메뉴의 등록 카테고리를 입력하세요 : ");
        int categoryCode = sc.nextInt();
        System.out.print("판매 등록 여부를 입력하세요 (Y or N) : ");
        sc.nextLine();
        String orderableStatus = sc.nextLine();

        MenuDTO newMenu = new MenuDTO();
        newMenu.setName(name);
        newMenu.setPrice(price);
        newMenu.setCategoryCode(categoryCode);
        newMenu.setOrderableStatus(orderableStatus);

        return newMenu;
    }
    private static MenuAndCategoryDTO inputNewCategoryAndMenu() {
        Scanner sc = new Scanner(System.in);

        System.out.print("신규 카테고리의 이름을 입력하세요 : ");
        String categoryName = sc.nextLine();
        System.out.print("신메뉴의 이름을 입력하세요 : ");
        String name = sc.nextLine();
        System.out.print("신메뉴의 가격을 입력하세요 : ");
        int price = sc.nextInt();
        System.out.print("판매 등록 여부를 입력하세요 (Y or N) : ");
        sc.nextLine();
        String orderableStatus = sc.nextLine();

        MenuAndCategoryDTO newMenu = new MenuAndCategoryDTO();
        CategoryDTO newCategory = new CategoryDTO();

        newCategory.setName(categoryName);

        newMenu.setCategory(newCategory);
        newMenu.setName(name);
        newMenu.setPrice(price);
        newMenu.setOrderableStatus(orderableStatus);

        return newMenu;
    }

}
