package com.mybatis5.section01.xmlmapper;

import com.mybatis5.common.CategoryAndMenuDTO;
import com.mybatis5.common.MenuAndCategoryDTO;
import com.mybatis5.common.MenuDTO;

import java.util.List;

public interface ElementTestMapper {

    List<String> selectCacheTest();

    List<MenuDTO> selectResultMapTest();

    List<MenuDTO> selectResultMapConstructorTest();

    List<MenuAndCategoryDTO> selectResultMapAssociationTest();

    List<CategoryAndMenuDTO> selectResultMapCollectionTest();

    List<MenuDTO> selectSqlTest();

    int insertMenu(MenuDTO menuDTO);

    int insertNewCategory(MenuAndCategoryDTO menuAndCategoryDTO);

    int insertNewMenu(MenuAndCategoryDTO menuAndCategoryDTO);

}
