package com.mybatis5.section01.xmlmapper;

import com.mybatis5.common.CategoryAndMenuDTO;
import com.mybatis5.common.MenuAndCategoryDTO;
import com.mybatis5.common.MenuDTO;
import org.apache.ibatis.session.SqlSession;

import java.util.List;

import static com.mybatis5.common.Template.getSqlSession;

public class ElementTestService {

    private ElementTestMapper mapper;

    public void selectCacheTest() {
        SqlSession sqlSession = getSqlSession();
        mapper = sqlSession.getMapper(ElementTestMapper.class);

        for(int i = 0; i < 10; i++) {
            Long startTime = System.currentTimeMillis();

            /* 최초 요청 시에는 시간이 걸리지만 그 이후에는 캐싱된 데이터를 불러오기 때문에 속도가 빠르다. */
            List<String> nameList = mapper.selectCacheTest();
            System.out.println(nameList);

            Long endTime = System.currentTimeMillis();

            Long interval = endTime - startTime;
            System.out.println("수행시간 : " + interval + "(ms)");
        }

        sqlSession.close();
    }

    public void selectResultMapTest() {
        SqlSession sqlSession = getSqlSession();
        mapper = sqlSession.getMapper(ElementTestMapper.class);

        List<MenuDTO> menuList = mapper.selectResultMapTest();
        for (MenuDTO menu : menuList) {
            System.out.println(menu);
        }

        sqlSession.close();
    }

    public void selectResultMapConstructorTest() {
        SqlSession sqlSession = getSqlSession();
        mapper = sqlSession.getMapper(ElementTestMapper.class);

        List<MenuDTO> menuList = mapper.selectResultMapConstructorTest();
        for (MenuDTO menu : menuList) {
            System.out.println(menu);
        }

        sqlSession.close();
    }

    public void selectResultMapAssociationTest() {
        SqlSession sqlSession = getSqlSession();
        mapper = sqlSession.getMapper(ElementTestMapper.class);

        List<MenuAndCategoryDTO> menuList = mapper.selectResultMapAssociationTest();
        for (MenuAndCategoryDTO menu : menuList) {
            System.out.println(menu);
        }

        sqlSession.close();
    }

    public void selectResultMapCollectionTest() {
        SqlSession sqlSession = getSqlSession();
        mapper = sqlSession.getMapper(ElementTestMapper.class);

        List<CategoryAndMenuDTO> categoryList = mapper.selectResultMapCollectionTest();
        for (CategoryAndMenuDTO category : categoryList) {
            System.out.println(category);
        }

        sqlSession.close();
    }

    public void selectSqlTest() {
        SqlSession sqlSession = getSqlSession();
        mapper = sqlSession.getMapper(ElementTestMapper.class);

        List<MenuDTO> menuList = mapper.selectSqlTest();
        for (MenuDTO menu : menuList) {
            System.out.println(menu);
        }

        sqlSession.close();
    }

    public void insertMenu(MenuDTO menuDTO) {
        SqlSession sqlSession = getSqlSession();
        mapper = sqlSession.getMapper(ElementTestMapper.class);

        int result = mapper.insertMenu(menuDTO);

        if(result > 0) {
            System.out.println("메뉴 등록 성공!");
            sqlSession.commit();
        } else {
            System.out.println("메뉴 등록 실패");
            sqlSession.rollback();
        }

        sqlSession.close();
    }

    public void insertCategoryAndMenu(MenuAndCategoryDTO menuAndCategoryDTO) {
        SqlSession sqlSession = getSqlSession();
        mapper = sqlSession.getMapper(ElementTestMapper.class);

        int result1 = mapper.insertNewCategory(menuAndCategoryDTO);
        int result2 = mapper.insertNewMenu(menuAndCategoryDTO);

        if(result1 > 0 && result2 > 0) {
            System.out.println("신규 카테고리 및 메뉴 등록 성공!");
            sqlSession.commit();
        } else {
            System.out.println("신규 카테고리 및 메뉴 등록 실패");
            sqlSession.rollback();
        }

        sqlSession.close();
    }
}
