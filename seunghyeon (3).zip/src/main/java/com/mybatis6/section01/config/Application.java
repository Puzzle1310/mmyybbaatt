package com.mybatis6.section01.config;

import com.mybatis6.common.MenuDTO;
import org.apache.ibatis.session.SqlSession;

import java.util.List;

import static com.mybatis6.common.Template.getSqlSession;

public class Application {

    public static void main(String[] args) {

        SqlSession sqlSession = getSqlSession();
        MenuMapper mapper = sqlSession.getMapper(MenuMapper.class);

        List<MenuDTO> menuList = mapper.selectMenuList();

        for(MenuDTO menu : menuList) {
            System.out.println(menu);
        }

        sqlSession.close();
    }

}
