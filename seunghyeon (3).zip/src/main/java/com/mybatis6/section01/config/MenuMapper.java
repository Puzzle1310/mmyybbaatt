package com.mybatis6.section01.config;

import com.mybatis6.common.MenuDTO;

import java.util.List;

public interface MenuMapper {

    List<MenuDTO> selectMenuList();

}
